﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            object o1 = a;
            Console.WriteLine(o1);

            int b = (int)o1;
            Console.WriteLine(b);



            Console.Read();


        }
    }
}

