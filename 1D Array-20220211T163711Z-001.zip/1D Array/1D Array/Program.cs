﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] course = { "BCA", "B.com", "BBA", "PGDCA" };

            foreach (string c in course)
            {
                Console.WriteLine(c);
            }
            Console.Read();
        }
    }
}
