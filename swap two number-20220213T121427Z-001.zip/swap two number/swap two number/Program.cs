﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace swap_two_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;

            Console.WriteLine("Enter No 1:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter No 2:");
            b = Convert.ToInt32(Console.ReadLine());

            c = a;
            a = b;
            b = c;
            Console.WriteLine("Swap Number:" + a + "  " + b);
            Console.Read();
        }
    }
}
