﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace for_print_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=1;i<=5;i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.Read();

        }
    }
}
