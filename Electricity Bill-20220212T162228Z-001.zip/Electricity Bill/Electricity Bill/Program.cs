﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Electricity_Bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int pr, cr,tot_u;

            Console.WriteLine("Enter Current Unit:");
            cr = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Previous Unit:");
            pr = Convert.ToInt32(Console.ReadLine());

            tot_u = cr - pr;
            Console.WriteLine("Total Use Unit:" + tot_u);

            Console.WriteLine("Enter Number 1 For Rural(Village) And  Number 2 for Urban(City)");
            int type = Convert.ToInt32(Console.ReadLine());
            int tot;

            if (cr > pr)
            {
                int tot_unit = cr - pr;
                switch (type)
                {
                    case 1:
                        if (tot_unit < 100)
                        {
                            tot = tot_unit * 6;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (100 <= tot_unit && tot_unit <= 200)
                        {
                            tot = tot_unit * 7;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (200 <= tot_unit && tot_unit <= 300)
                        {
                            tot = tot_unit * 8;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (300 <= tot_unit && tot_unit <= 400)
                        {
                            tot = tot_unit * 9;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else
                        {
                            tot = tot_unit * 10;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        break;
                    case 2:
                        if (tot_unit < 100)
                        {
                            tot = tot_unit * 6;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (100 <= tot_unit && tot_unit <= 200)
                        {
                            tot = tot_unit * 7;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (200 <= tot_unit && tot_unit <= 300)
                        {
                            tot = tot_unit * 8;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else if (300 <= tot_unit && tot_unit <= 400)
                        {
                            tot = tot_unit * 9;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        else
                        {
                            tot = tot_unit * 10;
                            Console.WriteLine("Your due bill costs : " + tot);
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Choose One From Rural Or Urban!..");
                        }
                        break;
                }
                Console.ReadLine();
            }
        }
    }
}
