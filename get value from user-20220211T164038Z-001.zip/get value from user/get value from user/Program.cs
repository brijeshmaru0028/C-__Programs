﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace get_value_from_user
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;

            Console.WriteLine("Enter a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a);

            Console.Read();
        }
    }
}
