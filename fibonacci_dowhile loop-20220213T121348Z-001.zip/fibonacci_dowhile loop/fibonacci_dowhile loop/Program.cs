﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibonacci_dowhile_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, i, no = 10;
            a = 0;
            b = 1;
            i = 2;
            Console.Write(a + " ");
            Console.Write(b + " ");
            do
            {
                c = a + b;
                a = b;
                b = c;
                Console.Write(" " + c);
                i++;
            }
            while (i != no);
            Console.Read();
        }
    }
}
