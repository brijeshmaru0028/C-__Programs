﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] a = new int[2][];

            a[0] = new int[] { 10, 20, 30 };
            a[1] = new int[] { 40, 50, 60, 70 };

            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine("Row({0})" + i);
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.WriteLine(" " + a[i][j]);
                }
            }
            Console.Read();
        }
    }
}
