﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ractanglular_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] number = new int[2, 2]
            {{10,20},{30,40} };


            foreach (int no in number)
            {
                Console.WriteLine(no);
            }
            Console.Read();
        }
    }
}
