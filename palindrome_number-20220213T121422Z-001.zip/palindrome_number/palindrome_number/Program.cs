﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace palindrome_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, r, a, s = 0;

            Console.WriteLine("Enter Number:");
            n = Convert.ToInt32(Console.ReadLine());

            a = n;
            while (n > 0)
            {
                r = n % 10;
                s = s * 10 + r;
                n = n / 10;
            }
            if (s == a)
            {
                Console.WriteLine("Number Is Palimdrome");
            }
            else
            {
                Console.WriteLine("Number Is Not Palindrome");
            }
            Console.Read();
        }
    }
}
