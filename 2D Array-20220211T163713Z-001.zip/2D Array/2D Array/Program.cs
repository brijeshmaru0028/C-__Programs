﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] course = new string[2, 2] { { "BCA", "MCA" }, { "BSC.IT", "MSC.IT" } };


            foreach (string c in course)
            {
                Console.WriteLine(c);
            }
            Console.Read();
        }
    }
}
