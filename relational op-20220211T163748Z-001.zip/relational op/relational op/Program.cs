﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace relational_op
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;

            if (a == b)
                Console.WriteLine("Equal No");
            if (a < b)
                Console.WriteLine("a is less than b");
            if (a > b)
                Console.WriteLine("a is grater than b");
            if (a <= b)
                Console.WriteLine("a is less than or equal b");
            if (a >= b)
                Console.WriteLine("a is grater than or equal b");

            Console.Read();

        }
    }
}
