﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arithmetic_operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition:" + (a + b));
            Console.WriteLine("Subtraction:" + (a - b));
            Console.WriteLine("Multiplication:" + (a * b));
            Console.WriteLine("Division:" + (a / b));

            Console.Read();
        }
    }
}
