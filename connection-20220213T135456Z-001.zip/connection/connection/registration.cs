﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace connection
{
    public partial class registration : Form
    {
        public registration()
        {
            InitializeComponent();
        }

        private void registration_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            clear();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                String i = "insert into login values('" + textBox1.Text + "','" + textBox2.Text + "')";
                SqlDataAdapter d = new SqlDataAdapter(i, Class1.c);
                DataTable t = new DataTable();
                int b = d.Fill(t);

                if (b >= 0)
                {
                    MessageBox.Show("Register..", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clear();
                }
                else
                {
                    MessageBox.Show("Not Register..", "Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    clear();
                }


            }
            else
            {
                MessageBox.Show("Please Enter Values...");
            }
        }
        private void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 a = new Form1();
            a.Show();
            this.Hide();
        }
    }
}
