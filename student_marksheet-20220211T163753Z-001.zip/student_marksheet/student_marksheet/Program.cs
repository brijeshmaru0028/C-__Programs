﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, m4, tot, per;
            Console.Write("Enter M1 : ");
            m1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter M2 : ");
            m2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter M3 :");
            m3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter M4 : ");
            m4 = Convert.ToInt32(Console.ReadLine());

            tot = m1 + m2 + m3 + m4;
            per = tot / 4;
            Console.WriteLine("Total Marks : " + tot);
            Console.WriteLine("Total Percentag :" + per);
            if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40)
            {
                if (per >= 70)
                {
                    Console.WriteLine("Grade is A");
                }
                else if (per >= 60)
                {
                    Console.WriteLine("Grade is B");
                }
                else if (per >= 50)
                {
                    Console.WriteLine("grae is C");
                }
                else
                {
                    Console.WriteLine("Grade is D");
                }
            }
            else
            {
                Console.WriteLine("Fail");
            }

            Console.Read();
        }
    }
}
